# - *- coding: utf- 8 - *-
from aiogram import Bot
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from tgbot.services.api_sqlite import get_paymentx, get_all_channelsx


# Выбор способов пополнения
def refill_select_finl():
    keyboard = InlineKeyboardMarkup()

    get_payments = get_paymentx()
    active_kb = []

    if get_payments['way_form'] == "True":
        active_kb.append(InlineKeyboardButton("📋 QIWI форма", callback_data="refill_select:Form"))
    if get_payments['way_number'] == "True":
        active_kb.append(InlineKeyboardButton("📞 QIWI номер", callback_data="refill_select:Number"))
    if get_payments['way_nickname'] == "True":
        active_kb.append(InlineKeyboardButton("Ⓜ QIWI никнейм", callback_data="refill_select:Nickname"))
    if get_payments['way_crypto'] == "True":
        active_kb.append(InlineKeyboardButton("Криптовалюта", callback_data="refill_select:Crypto"))
    if get_payments['way_lolz'] == "True":
        active_kb.append(InlineKeyboardButton("LolzTeam", callback_data="refill_select:Lolz"))

    if len(active_kb) == 5:
        keyboard.add(active_kb[0], active_kb[1])
        keyboard.add(active_kb[2], active_kb[3])
        keyboard.add(active_kb[4])
    if len(active_kb) == 4:
        keyboard.add(active_kb[0], active_kb[1])
        keyboard.add(active_kb[2], active_kb[3])
    if len(active_kb) == 3:
        keyboard.add(active_kb[0], active_kb[1])
        keyboard.add(active_kb[2])
    elif len(active_kb) == 2:
        keyboard.add(active_kb[0], active_kb[1])
    elif len(active_kb) == 1:
        keyboard.add(active_kb[0])
    else:
        keyboard = None

    if len(active_kb) >= 1:
        keyboard.add(InlineKeyboardButton("🔙 Вернуться", callback_data="user_profile"))

    return keyboard


# Проверка киви платежа
def refill_bill_finl(send_requests, get_receipt, get_way):
    keyboard = InlineKeyboardMarkup()

    keyboard.add(
        InlineKeyboardButton("🌀 Перейти к оплате", url=send_requests)
    ).add(
        InlineKeyboardButton("🔄 Проверить оплату", callback_data=f"Pay:{get_way}:{get_receipt}")
    )

    return keyboard


# Кнопки при открытии самого товара
def products_open_finl(position_id, category_id, remover):
    keyboard = InlineKeyboardMarkup()

    keyboard.add(
        InlineKeyboardButton("💰 Купить товар", callback_data=f"buy_item_open:{position_id}:{remover}")
    ).add(
        InlineKeyboardButton("🔙 Вернуться", callback_data=f"buy_category_open:{category_id}:{remover}")
    )

    return keyboard


# Подтверждение покупки товара
def products_confirm_finl(position_id, get_count):
    keyboard = InlineKeyboardMarkup()

    keyboard.add(
        InlineKeyboardButton("✅ Подтвердить", callback_data=f"buy_item_confirm:yes:{position_id}:{get_count}"),
        InlineKeyboardButton("❌ Отменить", callback_data=f"buy_item_confirm:not:{position_id}:{get_count}")
    )

    return keyboard


# Ссылка на поддержку
def user_support_finl(user_name):
    keyboard = InlineKeyboardMarkup()

    keyboard.add(
        InlineKeyboardButton("💌 Написать в поддержку", url=f"https://t.me/{user_name}"),
    )

    return keyboard


# Клавиатура с каналами для ОП
async def get_channels_keyboard(bot: Bot) -> InlineKeyboardMarkup: 
    channels = get_all_channelsx()

    keyboard = InlineKeyboardMarkup()
    buttons = [
        InlineKeyboardButton((await bot.get_chat(channel["telegram_id"])).title, url=channel["link"]) for channel in channels
    ]
    keyboard.add(*buttons)
    return keyboard



def get_rates_keyboard(rates) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()
    buttons = [
        InlineKeyboardButton(rate.source, callback_data=f'ChooseCrypto:{rate.source}') for rate in rates
    ]
    keyboard.add(*buttons)
    return keyboard


def get_crypto_pending_keyboard() -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()
    keyboard.row = 1
    buttons = [
        InlineKeyboardButton('Получить счет', callback_data='Pay:Crypto'),
        InlineKeyboardButton('Главное меню', callback_data='user_profile')
    ]
    keyboard.add(*buttons)

    return keyboard


def get_lolz_keyboard(url: str) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()
    keyboard.row_width = 2
    buttons = [
        InlineKeyboardButton('Оплатить', url=url),
        InlineKeyboardButton('Нажмите после оплаты', callback_data=f'lolz_invoice'),
    ]
    keyboard.row(*buttons)
    keyboard.add(InlineKeyboardButton('Главное меню', callback_data='user_profile'))

    return keyboard


def get_check_crypto_keyboard(invoice_id) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()
    buttons = [
        InlineKeyboardButton('Нажмите после оплаты', callback_data=f'crypto_invoice:{invoice_id}'),
    ]
    keyboard.add(*buttons)

    return keyboard