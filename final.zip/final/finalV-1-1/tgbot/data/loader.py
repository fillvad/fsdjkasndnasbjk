# - *- coding: utf- 8 - *-
from pathlib import Path
from aiogram import Bot, Dispatcher
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.types import ParseMode
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from aiocryptopay import AioCryptoPay, Networks


from api.lolzapi import LolzteamApi
from tgbot.services.api_sqlite import get_paymentx
from tgbot.data.config import BOT_TOKEN, PATH_DATABASE

bot = Bot(token=BOT_TOKEN, parse_mode=ParseMode.HTML)
dp = Dispatcher(bot, storage=MemoryStorage())
scheduler = AsyncIOScheduler(timezone="Europe/Moscow")


crypto_token, lolz_token, lolz_id = 'token', 'token', 1

if Path(PATH_DATABASE).is_file():
    payments = get_paymentx()
    crypto_token = payments['crypto_token']
    lolz_token = payments['lolz_token']
    lolz_id = payments['lolz_id']

crypto = AioCryptoPay(token=crypto_token, network=Networks.MAIN_NET)
lolz = LolzteamApi(lolz_token, lolz_id)
