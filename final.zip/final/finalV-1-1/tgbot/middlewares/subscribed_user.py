# - *- coding: utf- 8 - *-
from aiogram.dispatcher.middlewares import BaseMiddleware
from aiogram.dispatcher.handler import CancelHandler
from aiogram.types import Update

from tgbot.data.loader import bot
from tgbot.services.api_sqlite import get_all_channelsx
from tgbot.utils.misc_functions import is_subscribed
from tgbot.keyboards.inline_user import get_channels_keyboard

# Проверка подписки юзера на канал
class SubscribedUserMiddleware(BaseMiddleware):

    def __init__(self):
        self.prefix = "key_prefix"
        super(SubscribedUserMiddleware, self).__init__()

    async def on_process_update(self, update: Update, data: dict):
        if "message" in update:
            if update.message.text == '/start':
                return
            get_update = update.message
            chat_id = update.message.chat.id
        elif "callback_query" in update:
            get_update = update.callback_query
            chat_id = update.callback_query.from_user.id
        else:
            get_update = None
            chat_id = 0

        if get_update is not None and not get_update.from_user.is_bot:
            this_user = get_update.from_user

            channels = get_all_channelsx()
            
            if channels:
                if not all([await is_subscribed(bot, channel["telegram_id"], this_user.id) for channel in channels]):
                    await bot.send_message(chat_id, 'Пожалуйста, подпишитесь, чтобы дальше пользоваться ботом', reply_markup=(await get_channels_keyboard(bot)))
                    raise CancelHandler