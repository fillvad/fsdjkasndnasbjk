# - *- coding: utf- 8 - *-
import time

from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery, Message
from aiocryptopay.api import Assets

from api.lolzapi import TooManyRequestsException
from tgbot.data.loader import dp, crypto, lolz
from tgbot.services.api_qiwi import QiwiAPI
from tgbot.services.api_sqlite import get_paymentx
from tgbot.keyboards.inline_user import refill_bill_finl, refill_select_finl, get_rates_keyboard, get_crypto_pending_keyboard, get_check_crypto_keyboard, get_lolz_keyboard
from tgbot.services.api_sqlite import update_userx, get_refillx, add_refillx, get_userx
from tgbot.utils.const_functions import get_date, get_unix
from tgbot.utils.misc_functions import send_admins


min_input_qiwi = 5  # Минимальная сумма пополнения в рублях


# Выбор способа пополнения
@dp.callback_query_handler(text="user_refill", state="*")
async def refill_way(call: CallbackQuery, state: FSMContext):
    get_kb = refill_select_finl()

    if get_kb is not None:
        await call.message.edit_text("<b>💰 Выберите способ пополнения</b>", reply_markup=get_kb)
    else:
        await call.answer("⛔ Пополнение временно недоступно", True)


# Выбор способа пополнения
@dp.callback_query_handler(text_startswith="refill_select", state="*")
async def refill_way_select(call: CallbackQuery, state: FSMContext):
    get_way = call.data.split(":")[1]

    await state.update_data(here_pay_way=get_way)

    await state.set_state("here_refill_amount")
    await call.message.edit_text("<b>💰 Введите сумму пополнения</b>")


###################################################################################
#################################### ВВОД СУММЫ ###################################
# Принятие суммы для пополнения средств через QIWI
@dp.message_handler(state="here_refill_amount")
async def refill_get(message: Message, state: FSMContext):
    get_way = (await state.get_data())['here_pay_way']
    pay_amount = int(message.text)
    await state.finish()

    if not message.text.isdigit():
        await message.answer("<b>❌ Данные были введены неверно.</b>\n"
                             "💰 Введите сумму для пополнения средств")
        return

    if get_way == 'Crypto':
        rates = await crypto.get_exchange_rates()
        rates = [rate for rate in rates if rate. source in ("BNB", "ETH", "USDT", "BTC") and rate. target == 'RUB' ]
        await message.answer(f'Выберите криптовалюту для оплаты', reply_markup=get_rates_keyboard(rates), parse_mode='html')
        await state.set_state("choose_crypto")
        await state.set_data({"pay_amount": pay_amount})
        return
    
    if get_way == 'Lolz':
        comment = int(time.time() * 100)
        bot_username = (await message.bot.get_me()).username
        redirect = f'https:/t.me/{bot_username}'
        lolz_username = get_paymentx()["lolz_username"]

        url = f'https://lzt.market/balance/transfer?username={lolz_username}&amount={pay_amount}&comment={comment}'
        await message.answer(
            f'Оплатите по кнопке, а затем подтвердите оплату\n'
            '<i>ВНИМАНИЕ! Не изменяйте комментарий и юзернейм получателя, иначе деньги не поступят на счет!</i>',
            reply_markup=get_lolz_keyboard(url))
        await state.set_state("pay_lolz")
        await state.set_data({"pay_amount": pay_amount, "comment": comment})
        return

    # if get way is qiwi
    cache_message = await message.answer("<b>♻ Подождите, платёж генерируется...</b>")

    if min_input_qiwi <= pay_amount <= 300000:
        get_message, get_link, receipt = await (
            QiwiAPI(cache_message, pass_user=True)
        ).bill(pay_amount, get_way)

        if get_message:
            await cache_message.edit_text(get_message, reply_markup=refill_bill_finl(get_link, receipt, get_way))
    else:
        await cache_message.edit_text(
            f"<b>❌ Неверная сумма пополнения</b>\n"
            f"▶ Cумма не должна быть меньше <code>{min_input_qiwi}₽</code> и больше <code>300 000₽</code>\n"
            f"💰 Введите сумму для пополнения средств",
        )


@dp.callback_query_handler(text_startswith="ChooseCrypto", state="choose_crypto")
async def choose_crypto(call: CallbackQuery, state: FSMContext):
    await call.answer()

    curr = call.data.split(':')[-1]

    rates = await crypto.get_exchange_rates()         # get all rates
    rate = next(filter(lambda x: x.source == curr and x.target == 'RUB', rates)).rate
    amount_pay_rub = (await state.get_data())["pay_amount"]
    amount_pay_crypto = amount_pay_rub / rate

    await call.message.edit_text(f'Количество {curr} для оплаты: {amount_pay_crypto}', reply_markup=get_crypto_pending_keyboard())

    await state.set_data({"curr": curr, "amount": amount_pay_crypto, "amount_rub": amount_pay_rub})
    await state.set_state("crypto_pay")


@dp.callback_query_handler(text_startswith="Pay:Crypto", state="crypto_pay")
async def choose_crypto(call: CallbackQuery, state: FSMContext):
    await call.answer()

    data = await state.get_data()

    invoice = await crypto.create_invoice(data["curr"], data["amount"])
    await call.message.edit_text(f'Счет для оплаты: {invoice.pay_url}', reply_markup=get_check_crypto_keyboard(invoice.invoice_id))


@dp.callback_query_handler(text_startswith="crypto_invoice", state="crypto_pay")
async def check_crypto(call: CallbackQuery, state: FSMContext):
    data = await state.get_data()

    invoice_id = call.data.split(':')[-1]
    invoice = (await crypto.get_invoices(invoice_ids=invoice_id))[0]

    if invoice.status == 'paid':
        await refill_success(call, invoice_id, data["amount_rub"], "Crypto")
        await state.finish()
        await call.answer()
        return

    if invoice.status == 'active':
        await call.answer('Вы не оплатили счет! Оплатили и попробуйте снова')
    elif invoice.status == 'expired':
        await call.message.edit_text("<b>❌ Время оплаты вышло. Платёж был удалён. Попробуйте еще раз</b>")
        await call.answer() 


@dp.callback_query_handler(text_startswith="lolz_invoice", state="pay_lolz")
async def choose_crypto(call: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    amount = data["pay_amount"]
    comment = data["comment"]

    try: 
        payments = lolz.market_payments(type_='income', pmin=amount, pmax=amount, comment=comment)['payments']
    except TooManyRequestsException as e:
        await call.answer('Слишком много проверок! Подождите немного и попробуйте снова')
        return

    if not payments:
        await call.answer('Вы не оплатили счет! Оплатите и попробуйте снова')
        return
    
    await refill_success(call, comment, amount, "Lolz")
    await state.finish()
    await call.answer()


###################################################################################
################################ ПРОВЕРКА ПЛАТЕЖЕЙ ################################
# Проверка оплаты через форму
@dp.callback_query_handler(text_startswith="Pay:Form")
async def refill_check_form(call: CallbackQuery):
    receipt = call.data.split(":")[2]

    pay_status, pay_amount = await (
        QiwiAPI(call, pass_user=True)
    ).check_form(receipt)

    if pay_status == "PAID":
        get_refill = get_refillx(refill_receipt=receipt)
        if get_refill is None:
            await refill_success(call, receipt, pay_amount, "Form")
        else:
            await call.answer("❗ Ваше пополнение уже было зачислено.", True)
    elif pay_status == "EXPIRED":
        await call.message.edit_text("<b>❌ Время оплаты вышло. Платёж был удалён.</b>")
    elif pay_status == "WAITING":
        await call.answer("❗ Платёж не был найден.\n"
                          "⌛ Попробуйте чуть позже.", True, cache_time=5)
    elif pay_status == "REJECTED":
        await call.message.edit_text("<b>❌ Счёт был отклонён.</b>")


# Проверка оплаты по переводу (по нику или номеру)
@dp.callback_query_handler(text_startswith=['Pay:Number', 'Pay:Nickname'])
async def refill_check_send(call: CallbackQuery):
    way_pay = call.data.split(":")[1]
    receipt = call.data.split(":")[2]

    pay_status, pay_amount = await (
        QiwiAPI(call, pass_user=True)
    ).check_send(receipt)

    if pay_status == 1:
        await call.answer("❗ Оплата была произведена не в рублях.", True, cache_time=5)
    elif pay_status == 2:
        await call.answer("❗ Платёж не был найден.\n"
                          "⌛ Попробуйте чуть позже.", True, cache_time=5)
    elif pay_status == 4:
        pass
    else:
        get_refill = get_refillx(refill_receipt=receipt)
        if get_refill is None:
            await refill_success(call, receipt, pay_amount, way_pay)
        else:
            await call.answer("❗ Ваше пополнение уже зачислено.", True, cache_time=60)


##########################################################################################
######################################### ПРОЧЕЕ #########################################
# Зачисление средств
async def refill_success(call: CallbackQuery, receipt, amount, get_way):
    get_user = get_userx(user_id=call.from_user.id)

    add_refillx(get_user['user_id'], get_user['user_login'], get_user['user_name'], receipt,
                amount, receipt, get_way, get_date(), get_unix())

    update_userx(
        call.from_user.id,
        user_balance=get_user['user_balance'] + amount,
        user_refill=get_user['user_refill'] + amount,
    )

    await call.message.edit_text(
        f"<b>💰 Вы пополнили баланс на сумму <code>{amount}₽</code>. Удачи ❤\n"
        f"🧾 Чек: <code>#{receipt}</code></b>",
    )

    await send_admins(
        f"👤 Пользователь: <b>@{get_user['user_login']}</b> | <a href='tg://user?id={get_user['user_id']}'>{get_user['user_name']}</a> | <code>{get_user['user_id']}</code>\n"
        f"💰 Сумма пополнения: <code>{amount}₽</code>\n"
        f"🧾 Чек: <code>#{receipt}</code>"
    )
